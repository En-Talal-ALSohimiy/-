
from gui import open_gui

if __name__ == "__main__":
    open_gui()
