
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

def encrypt_aes256(input_file, key, iv):
    with open(input_file, 'rb') as f:
        data = f.read()
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
    encryptor = cipher.encryptor()
    padded_data = data + b"\0" * (16 - len(data) % 16)
    return iv + encryptor.update(padded_data) + encryptor.finalize()

def decrypt_aes256(data, key):
    iv = data[:16]
    encrypted_data = data[16:]
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
    decryptor = cipher.decryptor()
    decrypted = decryptor.update(encrypted_data) + decryptor.finalize()
    return decrypted.rstrip(b"\0")

def encrypt_chacha20(input_file, key, nonce):
    with open(input_file, 'rb') as f:
        data = f.read()
    cipher = Cipher(algorithms.ChaCha20(key, nonce), mode=None)
    encryptor = cipher.encryptor()
    return nonce + encryptor.update(data)

def decrypt_chacha20(data, key):
    nonce = data[:16]
    encrypted_data = data[16:]
    cipher = Cipher(algorithms.ChaCha20(key, nonce), mode=None)
    decryptor = cipher.decryptor()
    return decryptor.update(encrypted_data)
