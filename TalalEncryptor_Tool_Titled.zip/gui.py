
import tkinter as tk
from tkinter import filedialog, messagebox
import os
from hashlib import sha256
from encryptor import encrypt_aes256, encrypt_chacha20, decrypt_aes256, decrypt_chacha20
from utils import secure_delete
import arabic_reshaper
from bidi.algorithm import get_display

def ar(text):
    return get_display(arabic_reshaper.reshape(text))

def open_gui():
    root = tk.Tk()
    root.title("برمجة م. طلال السحيمي")  # العنوان لا يحتاج reshaper

    def select_file():
        path = filedialog.askopenfilename()
        entry_file.delete(0, tk.END)
        entry_file.insert(0, path)

    def perform_encryption():
        file_path = entry_file.get()
        raw_key = entry_key.get()
        algo = algo_var.get()
        delete_original = del_var.get()

        if not file_path or not raw_key:
            messagebox.showerror(ar("خطأ"), ar("يرجى إدخال جميع الحقول"))
            return

        try:
            key = sha256(raw_key.encode()).digest()

            if algo == "AES":
                iv = os.urandom(16)
                encrypted = encrypt_aes256(file_path, key, iv)
            else:
                nonce = os.urandom(16)
                encrypted = encrypt_chacha20(file_path, key, nonce)

            out_file = file_path + ".enc"
            with open(out_file, 'wb') as f:
                f.write(encrypted)

            if delete_original:
                secure_delete(file_path)

            messagebox.showinfo(ar("نجاح"), ar(f"تم تشفير الملف: {out_file}"))
        except Exception as e:
            messagebox.showerror(ar("خطأ"), str(e))

    def perform_decryption():
        file_path = entry_file.get()
        raw_key = entry_key.get()
        algo = algo_var.get()

        if not file_path or not raw_key:
            messagebox.showerror(ar("خطأ"), ar("يرجى إدخال جميع الحقول"))
            return

        try:
            key = sha256(raw_key.encode()).digest()
            with open(file_path, 'rb') as f:
                data = f.read()

            if algo == "AES":
                decrypted = decrypt_aes256(data, key)
            else:
                decrypted = decrypt_chacha20(data, key)

            out_file = file_path.replace(".enc", ".dec")
            with open(out_file, 'wb') as f:
                f.write(decrypted)

            messagebox.showinfo(ar("نجاح"), ar(f"تم فك التشفير إلى: {out_file}"))
        except Exception as e:
            messagebox.showerror(ar("خطأ"), str(e))

    tk.Label(root, text=ar("اختر الملف")).pack()
    entry_file = tk.Entry(root, width=50)
    entry_file.pack()
    tk.Button(root, text=ar("استعراض"), command=select_file).pack()

    tk.Label(root, text=ar("أدخل كلمة المرور / المفتاح")).pack()
    entry_key = tk.Entry(root, show="*")
    entry_key.pack()

    algo_var = tk.StringVar(value="AES")
    tk.Label(root, text=ar("اختر نوع التشفير")).pack()
    tk.Radiobutton(root, text="AES", variable=algo_var, value="AES").pack()
    tk.Radiobutton(root, text="ChaCha20", variable=algo_var, value="ChaCha20").pack()

    del_var = tk.BooleanVar()
    tk.Checkbutton(root, text=ar("حذف الملف الأصلي بعد التشفير"), variable=del_var).pack()

    tk.Button(root, text=ar("ابدأ التشفير"), command=perform_encryption).pack(pady=5)
    tk.Button(root, text=ar("فك التشفير"), command=perform_decryption).pack(pady=5)

    root.mainloop()
