
import os

def secure_delete(file_path, passes=3):
    if os.path.exists(file_path):
        length = os.path.getsize(file_path)
        for _ in range(passes):
            with open(file_path, "wb") as f:
                f.write(os.urandom(length))
        os.remove(file_path)
